import { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import type {
  ExcursionTheme,
  NearbyPoint,
  SupportedLocale,
} from '@/entities/excursion/model/types'
import { useDiscoveryRoutes } from '@/entities/excursion/model/useDiscoveryRoutes'
import {
  buildOsmWalkingRouteGeometryFromPoints,
  createLineGeometryFromPoints,
  getCachedWalkingRouteBuildResult,
  type LngLat,
} from '@/features/route-map/lib/route-geometry'
import { useUserGeolocation } from '@/features/route-map/model/useUserGeolocation'
import { useUserRoutes } from '@/features/user-routes/model/useUserRoutes'
import { appMapConfig } from '@/shared/config/map'
import { appRoutes } from '@/shared/config/routes'
import { clampDiscoveryRadius } from '@/shared/lib/discovery-radius'
import { matchesExcursionThemeFilter } from '@/shared/lib/excursion-theme'
import {
  detectSupportedLocale,
  getStoredDiscoveryContext,
  saveDiscoveryContext,
} from '@/shared/lib/discovery-context'

export const themeOptions: Array<ExcursionTheme | 'all'> = [
  'all',
  'walk',
  'food',
  'nature',
  'fun',
  'mixed',
]

export const durationOptions = [30, 45, 60, 90, 120] as const

// Route segments from OSRM. segments[0] is the guide segment (user→stop1) when hasLeadSegment=true.
export interface PlannerRouteState {
  hasLeadSegment: boolean
  segments: LngLat[][]
}

export function useExcursionsPageState(
  centerOverride?: { lat: number; lng: number } | null,
  effectiveUserPosition?: { lat: number; lng: number } | null,
) {
  const navigate = useNavigate()
  const {
    addPointToDraft,
    clearDraftRoute,
    draftStops,
    editingRouteSlug,
    isPointInDraft,
    reorderDraftStops,
    removeDraftStop,
    saveDraftRoute,
  } = useUserRoutes()

  const storedContext = useMemo(() => getStoredDiscoveryContext(), [])
  const detectedLocale = useMemo<SupportedLocale>(() => {
    if (typeof window === 'undefined') return storedContext.locale
    return detectSupportedLocale(
      navigator.languages?.[0] ?? navigator.language ?? storedContext.browserLocale,
    )
  }, [storedContext.browserLocale, storedContext.locale])

  const [locale] = useState<SupportedLocale>(storedContext.locale ?? detectedLocale)
  const [activeTheme, setActiveTheme] = useState<ExcursionTheme | 'all'>('all')
  const [maxDuration, setMaxDuration] = useState<number | null>(null)
  const [radiusMeters, setRadiusMeters] = useState(
    clampDiscoveryRadius(storedContext.radiusMeters ?? appMapConfig.discoveryRadiusMeters),
  )
  const [debouncedRadiusMeters, setDebouncedRadiusMeters] = useState(radiusMeters)
  const [selectedPointId, setSelectedPointId] = useState('')
  const [detailPointId, setDetailPointId] = useState<string | null>(null)
  const [expandedStopId, setExpandedStopId] = useState<string | null>(null)
  const [recenterKey, setRecenterKey] = useState(0)
  const [notice, setNotice] = useState<string | null>(null)
  const [draftFullBumpKey, setDraftFullBumpKey] = useState(0)
  const [isSavingRoute, setIsSavingRoute] = useState(false)
  const [routeSegmentsState, setRouteSegmentsState] = useState<{
    signature: string
    segments: LngLat[][]
  }>({ signature: '', segments: [] })

  const {
    error: geolocationError,
    requestLocation,
    status: geolocationStatus,
    userPosition,
  } = useUserGeolocation()

  const center = centerOverride ?? userPosition ?? storedContext.center
  const canLoadNearbyPlaces =
    Boolean(userPosition) || Boolean(centerOverride) || geolocationStatus === 'blocked' || geolocationStatus === 'unsupported'

  // Debounce radius changes to avoid excessive API calls while dragging slider
  useEffect(() => {
    const timerId = window.setTimeout(() => {
      setDebouncedRadiusMeters(radiusMeters)
    }, 600)
    return () => window.clearTimeout(timerId)
  }, [radiusMeters])

  const { error: discoveryError, excursions, isLoading, nearbyPoints } = useDiscoveryRoutes({
    activePointCategory: 'all',
    center,
    enabled: canLoadNearbyPlaces,
    locale,
    radiusMeters: debouncedRadiusMeters,
    search: '',
  })

  useEffect(() => {
    saveDiscoveryContext({
      activePointCategory: 'all',
      browserLocale:
        typeof window === 'undefined'
          ? storedContext.browserLocale
          : (navigator.languages?.[0] ?? navigator.language ?? storedContext.browserLocale),
      center,
      locale,
      radiusMeters,
      updatedAt: new Date().toISOString(),
    })
  }, [center, locale, radiusMeters, storedContext.browserLocale])

  useEffect(() => {
    if (!notice) return
    const id = window.setTimeout(() => setNotice(null), 2800)
    return () => window.clearTimeout(id)
  }, [notice])

  // Build route segments. When effectiveUserPosition is available it is prepended as point[0],
  // making segments[0] the guide segment (user → first stop), rendered dashed.
  const startPos = effectiveUserPosition ?? userPosition
  const cachedRouteSegments = useMemo(() => {
    if (draftStops.length === 0 || (draftStops.length === 1 && !startPos)) {
      return null
    }

    const points = [
      ...(startPos ? [startPos] : []),
      ...draftStops.map((stop) => stop.coordinates),
    ]
    const hasLeadSegment = Boolean(startPos)
    const signature = `${hasLeadSegment ? 'lead' : 'plain'}:${points
      .map((point) => `${point.lat.toFixed(5)}:${point.lng.toFixed(5)}`)
      .join('|')}`

    // Check each adjacent pair individually — the async effect caches pairs, not the full path
    const segments: LngLat[][] = []
    for (let i = 0; i < points.length - 1; i++) {
      const from = points[i]
      const to = points[i + 1]
      const cached = getCachedWalkingRouteBuildResult([from, to])
      if (!cached) return null
      if (cached.geometry?.type === 'LineString') {
        segments.push(cached.geometry.coordinates)
      } else if (cached.geometry?.type === 'MultiLineString') {
        segments.push(cached.geometry.coordinates[0] ?? [[from.lng, from.lat], [to.lng, to.lat]])
      } else {
        segments.push([[from.lng, from.lat], [to.lng, to.lat]])
      }
    }

    return { signature, segments }
  }, [draftStops, startPos])

  useEffect(() => {
    if (draftStops.length === 0 || (draftStops.length === 1 && !startPos)) {
      return
    }

    const hasLeadSegment = Boolean(startPos)
    const points = [
      ...(startPos ? [startPos] : []),
      ...draftStops.map((s) => s.coordinates),
    ]
    const signature = `${hasLeadSegment ? 'lead' : 'plain'}:${points
      .map((p) => `${p.lat.toFixed(5)}:${p.lng.toFixed(5)}`)
      .join('|')}`
    const controller = new AbortController()

    async function buildSegments() {
      const segments = await Promise.all(
        points.slice(0, -1).map(async (point, index) => {
          const next = points[index + 1]
          const result = await buildOsmWalkingRouteGeometryFromPoints(
            [point, next],
            controller.signal,
          ).catch(() => null)

          if (result?.geometry?.type === 'LineString') return result.geometry.coordinates
          if (result?.geometry?.type === 'MultiLineString') {
            return result.geometry.coordinates[0] ?? [[point.lng, point.lat], [next.lng, next.lat]]
          }
          return [[point.lng, point.lat], [next.lng, next.lat]] as LngLat[]
        }),
      )

      if (!controller.signal.aborted) {
        setRouteSegmentsState({ signature, segments })
      }
    }

    void buildSegments()
    return () => controller.abort()
  }, [draftStops, startPos])

  const filteredExcursions = useMemo(
    () =>
      excursions.filter(
        (ex) =>
          matchesExcursionThemeFilter(ex, activeTheme) &&
          (maxDuration === null || ex.durationMinutes <= maxDuration),
      ),
    [excursions, activeTheme, maxDuration],
  )

  const routePoints = useMemo(
    () => [
      ...(startPos ? [startPos] : []),
      ...draftStops.map((stop) => stop.coordinates),
    ],
    [draftStops, startPos],
  )

  const routeSignature = useMemo(() => {
    if (draftStops.length === 0 || (draftStops.length === 1 && !startPos)) return ''
    const prefix = startPos ? 'lead' : 'plain'
    return `${prefix}:${routePoints.map((p) => `${p.lat.toFixed(5)}:${p.lng.toFixed(5)}`).join('|')}`
  }, [draftStops.length, routePoints, startPos])

  const fallbackRouteSegments = useMemo(() => {
    if (!routeSignature) {
      return []
    }

    return routePoints.slice(0, -1).map((point, index) => {
      const nextPoint = routePoints[index + 1]
      const geometry = createLineGeometryFromPoints([point, nextPoint])
      return geometry.type === 'LineString' ? geometry.coordinates : []
    })
  }, [routePoints, routeSignature])

  const routeState = useMemo<PlannerRouteState>(() => {
    if (routeSegmentsState.signature === routeSignature) {
      return {
        hasLeadSegment: Boolean(startPos),
        segments:
          routeSegmentsState.segments.length > 0 ? routeSegmentsState.segments : fallbackRouteSegments,
      }
    }

    if (cachedRouteSegments?.signature === routeSignature) {
      return {
        hasLeadSegment: Boolean(startPos),
        segments:
          cachedRouteSegments.segments.length > 0
            ? cachedRouteSegments.segments
            : fallbackRouteSegments,
      }
    }

    if (routeSignature) {
      return { hasLeadSegment: Boolean(startPos), segments: fallbackRouteSegments }
    }
    return { hasLeadSegment: false, segments: [] }
  }, [
    cachedRouteSegments,
    fallbackRouteSegments,
    routeSegmentsState.segments,
    routeSegmentsState.signature,
    routeSignature,
    startPos,
  ])

  const handleSelectPoint = useCallback((pointId: string) => {
    setSelectedPointId(pointId)
    setDetailPointId(null)
  }, [])

  const handleShowDetail = useCallback((pointId: string) => {
    setDetailPointId(pointId)
  }, [])

  const handleCloseDetail = useCallback(() => {
    setDetailPointId(null)
  }, [])

  const handlePopupClose = useCallback(() => {
    setDetailPointId(null)
  }, [])

  const detailPoint = useMemo(
    () => (detailPointId !== null ? nearbyPoints.find((p) => p.id === detailPointId) ?? null : null),
    [detailPointId, nearbyPoints],
  )

  const handleAddPoint = useCallback(
    (point: NearbyPoint) => {
      if (isPointInDraft(point.id)) {
        setNotice('Точка уже добавлена в маршрут.')
        return
      }
      if (draftStops.length >= 10) {
        setDraftFullBumpKey((k) => k + 1)
        return
      }
      addPointToDraft(point)
      setSelectedPointId(point.id)
      if (!userPosition) requestLocation()
    },
    [addPointToDraft, draftStops.length, isPointInDraft, requestLocation, userPosition],
  )

  const handleRemoveStop = useCallback(
    (stopId: string) => {
      removeDraftStop(stopId)
      setExpandedStopId((id) => (id === stopId ? null : id))
    },
    [removeDraftStop],
  )

  const handleRemovePointFromDraft = useCallback(
    (pointId: string) => {
      const stop = draftStops.find(
        (s) => s.id.replace(/-draft-stop(?:-\d+)?$/, '') === pointId,
      )
      if (stop) removeDraftStop(stop.id)
    },
    [draftStops, removeDraftStop],
  )

  const handleSaveRoute = useCallback(() => {
    setIsSavingRoute(true)
    const result = saveDraftRoute()
    if (result.status === 'invalid') {
      setNotice('Добавьте минимум две точки.')
      setIsSavingRoute(false)
      return
    }
    if (result.route) {
      const route = result.route
      setExpandedStopId(null)
      setSelectedPointId('')
      setNotice(null)
      clearDraftRoute()
      setTimeout(() => {
        setIsSavingRoute(false)
        navigate(appRoutes.excursion(route.slug))
      }, 400)
    }
  }, [clearDraftRoute, navigate, saveDraftRoute])

  const handleClearRoute = useCallback(() => {
    clearDraftRoute()
    setExpandedStopId(null)
    setSelectedPointId('')
    setNotice(null)
  }, [clearDraftRoute])

  const handleLocateUser = useCallback(() => {
    if (!userPosition) {
      requestLocation()
      return
    }
    setRecenterKey((n) => n + 1)
  }, [requestLocation, userPosition])

  const handleReorderStop = useCallback(
    (fromIndex: number, toIndex: number) => {
      reorderDraftStops(fromIndex, toIndex)
    },
    [reorderDraftStops],
  )

  return {
    activeTheme,
    canLoadNearbyPlaces,
    center,
    detailPoint,
    discoveryError,
    draftFullBumpKey,
    draftStops,
    editingRouteSlug,
    excursions: filteredExcursions,
    expandedStopId,
    geolocationError,
    handleAddPoint,
    handleClearRoute,
    handleCloseDetail,
    handleLocateUser,
    handleReorderStop,
    handlePopupClose,
    handleRemovePointFromDraft,
    handleRemoveStop,
    handleSaveRoute,
    handleSelectPoint,
    handleShowDetail,
    isLoading,
    isPointInDraft,
    isSavingRoute,
    maxDuration,
    nearbyPoints,
    notice,
    radiusMeters,
    recenterKey,
    routeState,
    selectedPointId,
    setActiveTheme,
    setExpandedStopId,
    setMaxDuration,
    setRadiusMeters,
    userPosition,
  }
}
