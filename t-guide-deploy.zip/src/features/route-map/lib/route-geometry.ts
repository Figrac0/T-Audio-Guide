﻿import type { GeoPoint, RouteStop } from '@/entities/excursion/model/types'
import { appMapConfig } from '@/shared/config/map'

export type LngLat = [number, number]
export type LngLatBounds = [LngLat, LngLat]

export type RouteGeometry =
  | {
      type: 'LineString'
      coordinates: LngLat[]
    }
  | {
      type: 'MultiLineString'
      coordinates: LngLat[][]
    }

export type MapLocationRequest =
  | {
      center: LngLat
      zoom: number
      duration?: number
      easing?: string
      padding?: [number, number, number, number]
    }
  | {
      bounds: LngLatBounds
      duration?: number
      easing?: string
      padding?: [number, number, number, number]
    }

interface NearestStopResult {
  stop: RouteStop
  distanceMeters: number
}

export interface WalkingRouteBuildResult {
  geometry: RouteGeometry | null
  status: 'walking' | 'partial' | 'fallback'
}

interface OsrmRouteResponse {
  routes?: Array<{
    geometry?: {
      coordinates?: LngLat[]
      type?: string
    }
  }>
}

const fallbackBounds: LngLatBounds = [
  [appMapConfig.defaultCenter.lng - 0.01, appMapConfig.defaultCenter.lat - 0.01],
  [appMapConfig.defaultCenter.lng + 0.01, appMapConfig.defaultCenter.lat + 0.01],
]
const singlePointPadding = 0.006
const osrmWalkingEndpoint = 'https://router.project-osrm.org/route/v1/foot'
const walkingRouteCache = new Map<string, WalkingRouteBuildResult>()

export function toLngLat(point: GeoPoint): LngLat {
  return [point.lng, point.lat]
}

export function getBoundsFromStops(stops: RouteStop[]): LngLatBounds {
  return getBoundsFromPoints(stops.map((stop) => stop.coordinates))
}

export function getBoundsFromPoints(points: GeoPoint[]): LngLatBounds {
  return getBoundsFromLngLat(points.map((point) => toLngLat(point)))
}

export function getBoundsFromGeometry(geometry: RouteGeometry): LngLatBounds {
  if (geometry.type === 'LineString') {
    return getBoundsFromLngLat(geometry.coordinates)
  }

  return getBoundsFromLngLat(geometry.coordinates.flat())
}

export function createFallbackRouteGeometry(stops: RouteStop[]): RouteGeometry {
  return createLineGeometryFromPoints(stops.map((stop) => stop.coordinates))
}

export function createLineGeometryFromPoints(points: GeoPoint[]): RouteGeometry {
  return {
    type: 'LineString',
    coordinates: points.map((point) => toLngLat(point)),
  }
}

export function buildOsmWalkingRouteGeometry(stops: RouteStop[], signal?: AbortSignal) {
  return buildOsmWalkingRouteGeometryFromPoints(
    stops.map((stop) => stop.coordinates),
    signal,
  )
}

export function getWalkingRouteCacheKey(points: GeoPoint[]) {
  return points
    .map((point) => `${point.lat.toFixed(5)}:${point.lng.toFixed(5)}`)
    .join('|')
}

export function getCachedWalkingRouteBuildResult(points: GeoPoint[]) {
  return walkingRouteCache.get(getWalkingRouteCacheKey(points)) ?? null
}

export async function buildOsmWalkingRouteGeometryFromPoints(
  points: GeoPoint[],
  signal?: AbortSignal,
): Promise<WalkingRouteBuildResult> {
  if (points.length < 2) {
    return {
      geometry: null,
      status: 'fallback',
    }
  }

  const cacheKey = getWalkingRouteCacheKey(points)
  const cachedResult = walkingRouteCache.get(cacheKey)

  if (cachedResult) {
    return cachedResult
  }

  try {
    const segmentGeometries = await Promise.all(
      points.slice(0, -1).map(async (point, index) => {
        const nextPoint = points[index + 1]

        try {
          const geometry = await fetchOsmWalkingSegmentGeometry(point, nextPoint, signal)

          if (!geometry || geometry.length < 2) {
            return {
              geometry: null,
              resolved: false,
            }
          }

          return {
            geometry: {
              type: 'LineString',
              coordinates: geometry,
            } satisfies RouteGeometry,
            resolved: true,
          }
        } catch (error) {
          if (isAbortError(error)) {
            throw error
          }

          return {
            geometry: null,
            resolved: false,
          }
        }
      }),
    )

    const result = toWalkingRouteBuildResult(segmentGeometries)

    if (result.geometry && result.status !== 'fallback') {
      walkingRouteCache.set(cacheKey, result)
    }

    return result
  } catch (error) {
    if (isAbortError(error)) {
      throw error
    }

    return {
      geometry: null,
      status: 'fallback',
    }
  }
}

export function getNearestStop(
  stops: RouteStop[],
  userPosition: GeoPoint,
): NearestStopResult | null {
  let nearestStop: RouteStop | null = null
  let minDistance = Number.POSITIVE_INFINITY

  for (const stop of stops) {
    const distance = getDistanceMetersBetween(stop.coordinates, userPosition)

    if (distance < minDistance) {
      minDistance = distance
      nearestStop = stop
    }
  }

  if (!nearestStop) {
    return null
  }

  return {
    stop: nearestStop,
    distanceMeters: minDistance,
  }
}

export function getDistanceMetersBetween(from: GeoPoint, to: GeoPoint): number {
  const earthRadius = 6371000
  const fromLat = degreesToRadians(from.lat)
  const toLat = degreesToRadians(to.lat)
  const deltaLat = degreesToRadians(to.lat - from.lat)
  const deltaLng = degreesToRadians(to.lng - from.lng)

  const haversine =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(fromLat) *
      Math.cos(toLat) *
      Math.sin(deltaLng / 2) *
      Math.sin(deltaLng / 2)

  return 2 * earthRadius * Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine))
}

export function formatMeters(value: number): string {
  if (value < 1000) {
    return `${Math.round(value)} м`
  }

  return `${(value / 1000).toFixed(1).replace('.', ',')} км`
}

export function hexToRgba(hex: string, alpha: number): string {
  const normalized = hex.replace('#', '')
  const safeHex =
    normalized.length === 3
      ? normalized
          .split('')
          .map((character) => `${character}${character}`)
          .join('')
      : normalized

  const red = Number.parseInt(safeHex.slice(0, 2), 16)
  const green = Number.parseInt(safeHex.slice(2, 4), 16)
  const blue = Number.parseInt(safeHex.slice(4, 6), 16)

  return `rgba(${red}, ${green}, ${blue}, ${alpha})`
}

async function fetchOsmWalkingSegmentGeometry(
  from: GeoPoint,
  to: GeoPoint,
  signal?: AbortSignal,
): Promise<LngLat[] | null> {
  const params = new URLSearchParams({
    alternatives: 'false',
    annotations: 'false',
    geometries: 'geojson',
    overview: 'full',
    steps: 'false',
  })

  const response = await fetch(
    `${osrmWalkingEndpoint}/${from.lng},${from.lat};${to.lng},${to.lat}?${params.toString()}`,
    {
      headers: {
        Accept: 'application/json',
      },
      signal,
    },
  )

  if (!response.ok) {
    throw new Error(`OSRM responded with ${response.status}`)
  }

  const payload = (await response.json()) as OsrmRouteResponse
  const coordinates = payload.routes?.[0]?.geometry?.coordinates

  if (!Array.isArray(coordinates) || coordinates.length < 2) {
    return null
  }

  return coordinates
}

function getBoundsFromLngLat(points: LngLat[]): LngLatBounds {
  if (!points.length) {
    return fallbackBounds
  }

  if (points.length === 1) {
    const [lng, lat] = points[0]

    return [
      [lng - singlePointPadding, lat - singlePointPadding],
      [lng + singlePointPadding, lat + singlePointPadding],
    ]
  }

  const longitudes = points.map(([lng]) => lng)
  const latitudes = points.map(([, lat]) => lat)

  return [
    [Math.min(...longitudes), Math.min(...latitudes)],
    [Math.max(...longitudes), Math.max(...latitudes)],
  ]
}

function mergeSegmentGeometries(geometries: RouteGeometry[]): RouteGeometry | null {
  const segments = geometries.flatMap((geometry) =>
    geometry.type === 'LineString' ? [geometry.coordinates] : geometry.coordinates,
  )

  const validSegments = segments.filter((segment) => segment.length > 1)

  if (!validSegments.length) {
    return null
  }

  if (validSegments.length === 1) {
    return {
      type: 'LineString',
      coordinates: validSegments[0],
    }
  }

  return {
    type: 'MultiLineString',
    coordinates: validSegments,
  }
}

function toWalkingRouteBuildResult(
  segments: Array<{ geometry: RouteGeometry | null; resolved: boolean }>,
): WalkingRouteBuildResult {
  const resolvedSegments = segments.filter((segment) => segment.resolved)
  const resolvedGeometries = segments
    .map((segment) => segment.geometry)
    .filter((geometry): geometry is RouteGeometry => geometry !== null)

  if (!segments.length) {
    return {
      geometry: null,
      status: 'fallback',
    }
  }

  const geometry = mergeSegmentGeometries(resolvedGeometries)

  if (!geometry) {
    return {
      geometry: null,
      status: 'fallback',
    }
  }

  if (!resolvedSegments.length) {
    return {
      geometry,
      status: 'fallback',
    }
  }

  return {
    geometry,
    status: resolvedSegments.length === segments.length ? 'walking' : 'partial',
  }
}

function isAbortError(error: unknown) {
  return error instanceof DOMException && error.name === 'AbortError'
}

function degreesToRadians(value: number): number {
  return (value * Math.PI) / 180
}
